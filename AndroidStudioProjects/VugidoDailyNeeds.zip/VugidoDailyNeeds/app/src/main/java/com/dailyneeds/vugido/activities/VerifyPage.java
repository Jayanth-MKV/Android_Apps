package com.dailyneeds.vugido.activities;

import android.content.Intent;
import android.os.Bundle;
import androidx.annotation.Nullable;
import androidx.core.content.res.ResourcesCompat;
import androidx.appcompat.app.AppCompatActivity;

import android.view.View;
import android.widget.Button;

import com.chaos.view.PinView;
import com.dailyneeds.vugido.R;

public class VerifyPage extends AppCompatActivity implements View.OnClickListener {
PinView pinView;
Button VerifyButton;
    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.verifypage);
        VerifyButton=findViewById(R.id.verify_button);
        VerifyButton.setOnClickListener(this);


    }

    @Override
    public void onClick(View v) {

        startActivity(new Intent(VerifyPage.this,MainActivity.class));

    }
}
