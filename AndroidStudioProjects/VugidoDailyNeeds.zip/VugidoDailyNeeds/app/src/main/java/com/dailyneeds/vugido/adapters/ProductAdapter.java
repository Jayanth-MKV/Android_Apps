package com.dailyneeds.vugido.adapters;

import android.content.Context;
import androidx.annotation.NonNull;
import androidx.fragment.app.FragmentManager;
import androidx.fragment.app.FragmentTransaction;
import androidx.recyclerview.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;
import com.dailyneeds.vugido.R;
import com.dailyneeds.vugido.fragments.ProductAddOnDialog;

public class ProductAdapter extends RecyclerView.Adapter<ProductAdapter.MyViewHolder> {

    private Context context;
    private int cat;
    private FragmentManager fragmentManager;
    public ProductAdapter(Context context,FragmentManager fragmentManager,int cat){
        this.context=context;
        this.fragmentManager=fragmentManager;
        this.cat=cat;
    }


    @NonNull
    @Override
    public MyViewHolder onCreateViewHolder(@NonNull ViewGroup viewGroup, int i) {
        LayoutInflater layoutInflater= (LayoutInflater) context.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
        assert layoutInflater != null;
        View view=layoutInflater.inflate(R.layout.product_design,viewGroup,false);
        return new MyViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull final MyViewHolder holder, int position) {
        holder.add.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if(cat==0){
                    holder.image.setImageDrawable(context.getDrawable(R.drawable.tomato_img));
                }
                else {
                    holder.image.setImageDrawable(context.getDrawable(R.drawable.orange));
                }
                FragmentTransaction ft = fragmentManager.beginTransaction();
                ProductAddOnDialog productAddOnDialog=new ProductAddOnDialog();
                productAddOnDialog.show(ft,"ADD_ON");


            }
        });

    }


    @Override
    public int getItemCount() {
        return 10;
    }

    static class MyViewHolder extends RecyclerView.ViewHolder{
        ImageView add,image;
        TextView name,price,quantity;

        MyViewHolder(@NonNull View itemView) {
            super(itemView);

            add=itemView.findViewById(R.id.product_add);
            image=itemView.findViewById(R.id.product_image);
            name=itemView.findViewById(R.id.product_name);
            price=itemView.findViewById(R.id.product_price);
            quantity=itemView.findViewById(R.id.product_quantity);

        }
    }
}
