package com.dailyneeds.vugido.fragments;

import android.content.Context;
import android.os.Bundle;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import com.dailyneeds.vugido.R;
import com.dailyneeds.vugido.adapters.ProductAdapter;
import com.dailyneeds.vugido.design.Space;


public class Vegetables extends Fragment {
    private Context context;

    @Override
    public void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        context=getContext();
    }

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
       View view=  inflater.inflate(R.layout.vegetables_fragment,container,false);
        RecyclerView recyclerView=view.findViewById(R.id.veg_recyclerView);
        ProductAdapter productAdapter=new ProductAdapter(context,getFragmentManager(),0);
        GridLayoutManager gridLayoutManager=new GridLayoutManager(context,2);
        recyclerView.setLayoutManager(gridLayoutManager);
        recyclerView.addItemDecoration(new Space(2,20,true,0));
        recyclerView.setAdapter(productAdapter);
       return view;
    }
}
