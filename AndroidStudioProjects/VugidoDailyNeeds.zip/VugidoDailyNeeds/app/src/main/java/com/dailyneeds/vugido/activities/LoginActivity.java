package com.dailyneeds.vugido.activities;

import android.content.Intent;
import android.os.Bundle;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;
import android.view.View;
import android.widget.ImageButton;

import com.dailyneeds.vugido.R;


public class LoginActivity extends AppCompatActivity implements View.OnClickListener {

    ImageButton SendOtp;
    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.login);
        SendOtp=findViewById(R.id.sendOtpButton);
        SendOtp.setOnClickListener(this);
    }

    @Override
    public void onClick(View v) {
        startActivity(new Intent(LoginActivity.this,VerifyPage.class));
    }
}
