package com.dailyneeds.vugido.adapters;

import android.content.Context;
import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import com.dailyneeds.vugido.R;

public class CartAdapter extends RecyclerView.Adapter <CartAdapter.MyViewHolder>{

    private Context context;
    public CartAdapter(Context context){
        this.context=context;

    }

    @NonNull
    @Override
    public MyViewHolder onCreateViewHolder(@NonNull ViewGroup viewGroup, int i) {
        LayoutInflater layoutInflater= (LayoutInflater) context.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
        assert layoutInflater != null;
        View view=layoutInflater.inflate(R.layout.cart_row_design,viewGroup,false);
        return new MyViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull MyViewHolder myViewHolder, int i) {


    }

    @Override
    public int getItemCount() {
        return 10;
    }

    static class MyViewHolder extends RecyclerView.ViewHolder{

        TextView name,quantity,price;
        MyViewHolder(@NonNull View itemView) {
            super(itemView);

            name=itemView.findViewById(R.id.CartItemName);
            quantity=itemView.findViewById(R.id.CartItemQuantity);
            price=itemView.findViewById(R.id.CartItemPrice);

        }
    }
}
