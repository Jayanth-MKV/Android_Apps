package com.imgideongo.vfp.models;

public class ActiveOrderItems {

    private String ItemName;
    private String Count;

    public String getItemName() {
        return ItemName;
    }

    public void setItemName(String itemName) {
        ItemName = itemName;
    }

    public String getCount() {
        return Count;
    }

    public void setCount(String count) {
        Count = count;
    }
}
