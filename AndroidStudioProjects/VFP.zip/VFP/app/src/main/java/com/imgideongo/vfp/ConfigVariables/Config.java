package com.imgideongo.vfp.ConfigVariables;

public class Config {

    public static final String URL_ADD_ITEM_INFO="https://www.vurjana.com/VFP/ADD_ITEM.php";
    public static final String URL_LOGIN_VFP ="http://192.168.43.134/VD_INVENTORY_END/VFP_LOGIN.php" ;
    public static final String URL_GET_DASHBOARD_ITEMS="https://www.vurjana.com/VFP/GET_DASHBOARD_ITEMS.php";
    public static final String URL_CLIENT_LOGO="https://www.vurjana.com/VFP/";
    public static final String URL_DEACTIVATE_ITEM ="https://www.vurjana.com/VFP/ACTIVE_ITEM_STATE.php" ;
    public static final String URL_CID_FIRE_BASE_TOKEN = "https://www.vurjana.com/VFP/UPDATE_VFP_FB_TOKEN.php";
    public static final String GET_ACTIVE_VFP_ORDER = "https://www.vurjana.com/Vugido/GET_VFP_ACTIVE_ORDER.php";
}
