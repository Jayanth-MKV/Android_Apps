package com.imgideongo.vfp.ConfigVariables;

public class NotificationConstants {

    public static final String CHANNEL_ID = "NOTIFICATION_CHANNEL_1";
    public static final String CHANNEL_NAME="Vugido";
    public static final String CHANNEL_DESCRIPTION="www.vugido.com";
}